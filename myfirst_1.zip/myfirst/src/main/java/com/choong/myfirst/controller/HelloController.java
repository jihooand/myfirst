package com.choong.myfirst.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HelloController {

    //localhost:8090/
    @GetMapping("")
    public String hello() {
        return "hellotest"; //html파일
    }

    //localhost:8090/index
    @GetMapping("index")
    public String index(Model model) {
        model.addAttribute("testStr", "Hello World!!");
        model.addAttribute("name", "이경희");
        return "index"; //html파일
    }

    //localhost:8090/index/hello
    @GetMapping("index/hello")
    public String indexHello() {
        return "indexHello"; //html 파일
    }

}
